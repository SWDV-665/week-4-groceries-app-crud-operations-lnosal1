import { Component } from '@angular/core';
import { ToastController } from '@ionic/angular';
import { AlertController } from '@ionic/angular';
import { GroceriesServiceService } from '../groceries-service.service';
import { InputDialogService } from '../input-dialog.service';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {
  tabtitle = "Grocery List";


constructor(public toastController: ToastController, public alertController: AlertController, public dataService: GroceriesServiceService, public inputDialog: InputDialogService) {

  } 
  
  loadItems() {
    return this.dataService.items;
  }
  
  async presentToast(item, index) {
    const toast = await this.toastController.create({
      message: 'your item has been removed from the list',
      duration: 2000
    });
    toast.present();

    this.dataService.removeItem(index);
  }

  async editItem(item, index) {
    const toast = await this.toastController.create({
      message: 'your item has been edited' ,
      duration: 2000
    });
    toast.present();
    console.log("testing"); 
    this.inputDialog.showPrompt(item, index);
  }

  additem() {
    console.log("Item Added");
    this.inputDialog.showPrompt();
  }

  
}



